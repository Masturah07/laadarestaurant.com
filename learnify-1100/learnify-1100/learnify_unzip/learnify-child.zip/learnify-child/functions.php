<?php
/**
 * Child-Theme functions and definitions
 */

function learnify_child_scripts() {
    wp_enqueue_style( 'learnify-parent-style', get_template_directory_uri(). '/style.css' );
}

add_filter('wp_enqueue_scripts', 'learnify_child_scripts');

?>