<?php
/**
 * The template to display single post
 *
 * @package LEARNIFY
 * @since LEARNIFY 1.0
 */

// Full post loading
$full_post_loading          = learnify_get_value_gp( 'action' ) == 'full_post_loading';

// Prev post loading
$prev_post_loading          = learnify_get_value_gp( 'action' ) == 'prev_post_loading';
$prev_post_loading_type     = learnify_get_theme_option( 'posts_navigation_scroll_which_block' );

// Position of the related posts
$learnify_related_position   = learnify_get_theme_option( 'related_position' );

// Type of the prev/next post navigation
$learnify_posts_navigation   = learnify_get_theme_option( 'posts_navigation' );
$learnify_prev_post          = false;
$learnify_prev_post_same_cat = learnify_get_theme_option( 'posts_navigation_scroll_same_cat' );

// Rewrite style of the single post if current post loading via AJAX and featured image and title is not in the content
if ( ( $full_post_loading 
		|| 
		( $prev_post_loading && 'article' == $prev_post_loading_type )
	) 
	&& 
	! in_array( learnify_get_theme_option( 'single_style' ), array( 'style-6' ) )
) {
	learnify_storage_set_array( 'options_meta', 'single_style', 'style-6' );
}

do_action( 'learnify_action_prev_post_loading', $prev_post_loading, $prev_post_loading_type );

get_header();

while ( have_posts() ) {

	the_post();

	// Type of the prev/next post navigation
	if ( 'scroll' == $learnify_posts_navigation ) {
		$learnify_prev_post = get_previous_post( $learnify_prev_post_same_cat );  // Get post from same category
		if ( ! $learnify_prev_post && $learnify_prev_post_same_cat ) {
			$learnify_prev_post = get_previous_post( false );                    // Get post from any category
		}
		if ( ! $learnify_prev_post ) {
			$learnify_posts_navigation = 'links';
		}
	}

	// Override some theme options to display featured image, title and post meta in the dynamic loaded posts
	if ( $full_post_loading || ( $prev_post_loading && $learnify_prev_post ) ) {
		learnify_sc_layouts_showed( 'featured', false );
		learnify_sc_layouts_showed( 'title', false );
		learnify_sc_layouts_showed( 'postmeta', false );
	}

	// If related posts should be inside the content
	if ( strpos( $learnify_related_position, 'inside' ) === 0 ) {
		ob_start();
	}

	// Display post's content
	get_template_part( apply_filters( 'learnify_filter_get_template_part', 'templates/content', 'single-' . learnify_get_theme_option( 'single_style' ) ), 'single-' . learnify_get_theme_option( 'single_style' ) );

	// If related posts should be inside the content
	if ( strpos( $learnify_related_position, 'inside' ) === 0 ) {
		$learnify_content = ob_get_contents();
		ob_end_clean();

		ob_start();
		do_action( 'learnify_action_related_posts' );
		$learnify_related_content = ob_get_contents();
		ob_end_clean();

		if ( ! empty( $learnify_related_content ) ) {
			$learnify_related_position_inside = max( 0, min( 9, learnify_get_theme_option( 'related_position_inside' ) ) );
			if ( 0 == $learnify_related_position_inside ) {
				$learnify_related_position_inside = mt_rand( 1, 9 );
			}

			$learnify_p_number         = 0;
			$learnify_related_inserted = false;
			$learnify_in_block         = false;
			$learnify_content_start    = strpos( $learnify_content, '<div class="post_content' );
			$learnify_content_end      = strrpos( $learnify_content, '</div>' );

			for ( $i = max( 0, $learnify_content_start ); $i < min( strlen( $learnify_content ) - 3, $learnify_content_end ); $i++ ) {
				if ( $learnify_content[ $i ] != '<' ) {
					continue;
				}
				if ( $learnify_in_block ) {
					if ( strtolower( substr( $learnify_content, $i + 1, 12 ) ) == '/blockquote>' ) {
						$learnify_in_block = false;
						$i += 12;
					}
					continue;
				} else if ( strtolower( substr( $learnify_content, $i + 1, 10 ) ) == 'blockquote' && in_array( $learnify_content[ $i + 11 ], array( '>', ' ' ) ) ) {
					$learnify_in_block = true;
					$i += 11;
					continue;
				} else if ( 'p' == $learnify_content[ $i + 1 ] && in_array( $learnify_content[ $i + 2 ], array( '>', ' ' ) ) ) {
					$learnify_p_number++;
					if ( $learnify_related_position_inside == $learnify_p_number ) {
						$learnify_related_inserted = true;
						$learnify_content = ( $i > 0 ? substr( $learnify_content, 0, $i ) : '' )
											. $learnify_related_content
											. substr( $learnify_content, $i );
					}
				}
			}
			if ( ! $learnify_related_inserted ) {
				if ( $learnify_content_end > 0 ) {
					$learnify_content = substr( $learnify_content, 0, $learnify_content_end ) . $learnify_related_content . substr( $learnify_content, $learnify_content_end );
				} else {
					$learnify_content .= $learnify_related_content;
				}
			}
		}

		learnify_show_layout( $learnify_content );
	}

	// Comments
	do_action( 'learnify_action_before_comments' );
	comments_template();
	do_action( 'learnify_action_after_comments' );

	// Related posts
	if ( 'below_content' == $learnify_related_position
		&& ( 'scroll' != $learnify_posts_navigation || learnify_get_theme_option( 'posts_navigation_scroll_hide_related' ) == 0 )
		&& ( ! $full_post_loading || learnify_get_theme_option( 'open_full_post_hide_related' ) == 0 )
	) {
		do_action( 'learnify_action_related_posts' );
	}

	// Post navigation: type 'scroll'
	if ( 'scroll' == $learnify_posts_navigation && ! $full_post_loading ) {
		?>
		<div class="nav-links-single-scroll"
			data-post-id="<?php echo esc_attr( get_the_ID( $learnify_prev_post ) ); ?>"
			data-post-link="<?php echo esc_attr( get_permalink( $learnify_prev_post ) ); ?>"
			data-post-title="<?php the_title_attribute( array( 'post' => $learnify_prev_post ) ); ?>"
			<?php do_action( 'learnify_action_nav_links_single_scroll_data', $learnify_prev_post ); ?>
		></div>
		<?php
	}
}

get_footer();
