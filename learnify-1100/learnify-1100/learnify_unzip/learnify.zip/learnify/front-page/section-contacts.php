<div class="front_page_section front_page_section_contacts<?php
	$learnify_scheme = learnify_get_theme_option( 'front_page_contacts_scheme' );
	if ( ! empty( $learnify_scheme ) && ! learnify_is_inherit( $learnify_scheme ) ) {
		echo ' scheme_' . esc_attr( $learnify_scheme );
	}
	echo ' front_page_section_paddings_' . esc_attr( learnify_get_theme_option( 'front_page_contacts_paddings' ) );
	if ( learnify_get_theme_option( 'front_page_contacts_stack' ) ) {
		echo ' sc_stack_section_on';
	}
?>"
		<?php
		$learnify_css      = '';
		$learnify_bg_image = learnify_get_theme_option( 'front_page_contacts_bg_image' );
		if ( ! empty( $learnify_bg_image ) ) {
			$learnify_css .= 'background-image: url(' . esc_url( learnify_get_attachment_url( $learnify_bg_image ) ) . ');';
		}
		if ( ! empty( $learnify_css ) ) {
			echo ' style="' . esc_attr( $learnify_css ) . '"';
		}
		?>
>
<?php
	// Add anchor
	$learnify_anchor_icon = learnify_get_theme_option( 'front_page_contacts_anchor_icon' );
	$learnify_anchor_text = learnify_get_theme_option( 'front_page_contacts_anchor_text' );
if ( ( ! empty( $learnify_anchor_icon ) || ! empty( $learnify_anchor_text ) ) && shortcode_exists( 'trx_sc_anchor' ) ) {
	echo do_shortcode(
		'[trx_sc_anchor id="front_page_section_contacts"'
									. ( ! empty( $learnify_anchor_icon ) ? ' icon="' . esc_attr( $learnify_anchor_icon ) . '"' : '' )
									. ( ! empty( $learnify_anchor_text ) ? ' title="' . esc_attr( $learnify_anchor_text ) . '"' : '' )
									. ']'
	);
}
?>
	<div class="front_page_section_inner front_page_section_contacts_inner
	<?php
	if ( learnify_get_theme_option( 'front_page_contacts_fullheight' ) ) {
		echo ' learnify-full-height sc_layouts_flex sc_layouts_columns_middle';
	}
	?>
			"
			<?php
			$learnify_css      = '';
			$learnify_bg_mask  = learnify_get_theme_option( 'front_page_contacts_bg_mask' );
			$learnify_bg_color_type = learnify_get_theme_option( 'front_page_contacts_bg_color_type' );
			if ( 'custom' == $learnify_bg_color_type ) {
				$learnify_bg_color = learnify_get_theme_option( 'front_page_contacts_bg_color' );
			} elseif ( 'scheme_bg_color' == $learnify_bg_color_type ) {
				$learnify_bg_color = learnify_get_scheme_color( 'bg_color', $learnify_scheme );
			} else {
				$learnify_bg_color = '';
			}
			if ( ! empty( $learnify_bg_color ) && $learnify_bg_mask > 0 ) {
				$learnify_css .= 'background-color: ' . esc_attr(
					1 == $learnify_bg_mask ? $learnify_bg_color : learnify_hex2rgba( $learnify_bg_color, $learnify_bg_mask )
				) . ';';
			}
			if ( ! empty( $learnify_css ) ) {
				echo ' style="' . esc_attr( $learnify_css ) . '"';
			}
			?>
	>
		<div class="front_page_section_content_wrap front_page_section_contacts_content_wrap content_wrap">
			<?php

			// Title and description
			$learnify_caption     = learnify_get_theme_option( 'front_page_contacts_caption' );
			$learnify_description = learnify_get_theme_option( 'front_page_contacts_description' );
			if ( ! empty( $learnify_caption ) || ! empty( $learnify_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				// Caption
				if ( ! empty( $learnify_caption ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
					?>
					<h2 class="front_page_section_caption front_page_section_contacts_caption front_page_block_<?php echo ! empty( $learnify_caption ) ? 'filled' : 'empty'; ?>">
					<?php
						echo wp_kses( $learnify_caption, 'learnify_kses_content' );
					?>
					</h2>
					<?php
				}

				// Description
				if ( ! empty( $learnify_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
					?>
					<div class="front_page_section_description front_page_section_contacts_description front_page_block_<?php echo ! empty( $learnify_description ) ? 'filled' : 'empty'; ?>">
					<?php
						echo wp_kses( wpautop( $learnify_description ), 'learnify_kses_content' );
					?>
					</div>
					<?php
				}
			}

			// Content (text)
			$learnify_content = learnify_get_theme_option( 'front_page_contacts_content' );
			$learnify_layout  = learnify_get_theme_option( 'front_page_contacts_layout' );
			if ( 'columns' == $learnify_layout && ( ! empty( $learnify_content ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) ) {
				?>
				<div class="front_page_section_columns front_page_section_contacts_columns columns_wrap">
					<div class="column-1_3">
				<?php
			}

			if ( ( ! empty( $learnify_content ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) ) {
				?>
				<div class="front_page_section_content front_page_section_contacts_content front_page_block_<?php echo ! empty( $learnify_content ) ? 'filled' : 'empty'; ?>">
					<?php
					echo wp_kses( $learnify_content, 'learnify_kses_content' );
					?>
				</div>
				<?php
			}

			if ( 'columns' == $learnify_layout && ( ! empty( $learnify_content ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) ) {
				?>
				</div><div class="column-2_3">
				<?php
			}

			// Shortcode output
			$learnify_sc = learnify_get_theme_option( 'front_page_contacts_shortcode' );
			if ( ! empty( $learnify_sc ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<div class="front_page_section_output front_page_section_contacts_output front_page_block_<?php echo ! empty( $learnify_sc ) ? 'filled' : 'empty'; ?>">
					<?php
					learnify_show_layout( do_shortcode( $learnify_sc ) );
					?>
				</div>
				<?php
			}

			if ( 'columns' == $learnify_layout && ( ! empty( $learnify_content ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) ) {
				?>
				</div></div>
				<?php
			}
			?>

		</div>
	</div>
</div>
