<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package LEARNIFY
 * @since LEARNIFY 1.0
 */

if ( learnify_sidebar_present() ) {
	
	$learnify_sidebar_type = learnify_get_theme_option( 'sidebar_type' );
	if ( 'custom' == $learnify_sidebar_type && ! learnify_is_layouts_available() ) {
		$learnify_sidebar_type = 'default';
	}
	
	// Catch output to the buffer
	ob_start();
	if ( 'default' == $learnify_sidebar_type ) {
		// Default sidebar with widgets
		$learnify_sidebar_name = learnify_get_theme_option( 'sidebar_widgets' );
		learnify_storage_set( 'current_sidebar', 'sidebar' );
		if ( is_active_sidebar( $learnify_sidebar_name ) ) {
			dynamic_sidebar( $learnify_sidebar_name );
		}
	} else {
		// Custom sidebar from Layouts Builder
		$learnify_sidebar_id = learnify_get_custom_sidebar_id();
		do_action( 'learnify_action_show_layout', $learnify_sidebar_id );
	}
	$learnify_out = trim( ob_get_contents() );
	ob_end_clean();
	
	// If any html is present - display it
	if ( ! empty( $learnify_out ) ) {
		$learnify_sidebar_position    = learnify_get_theme_option( 'sidebar_position' );
		$learnify_sidebar_position_ss = learnify_get_theme_option( 'sidebar_position_ss' );
		?>
		<div class="sidebar widget_area
			<?php
			echo ' ' . esc_attr( $learnify_sidebar_position );
			echo ' sidebar_' . esc_attr( $learnify_sidebar_position_ss );
			echo ' sidebar_' . esc_attr( $learnify_sidebar_type );

			$learnify_sidebar_scheme = apply_filters( 'learnify_filter_sidebar_scheme', learnify_get_theme_option( 'sidebar_scheme' ) );
			if ( ! empty( $learnify_sidebar_scheme ) && ! learnify_is_inherit( $learnify_sidebar_scheme ) && 'custom' != $learnify_sidebar_type ) {
				echo ' scheme_' . esc_attr( $learnify_sidebar_scheme );
			}
			?>
		" role="complementary">
			<?php

			// Skip link anchor to fast access to the sidebar from keyboard
			?>
			<a id="sidebar_skip_link_anchor" class="learnify_skip_link_anchor" href="#"></a>
			<?php

			do_action( 'learnify_action_before_sidebar_wrap', 'sidebar' );

			// Button to show/hide sidebar on mobile
			if ( in_array( $learnify_sidebar_position_ss, array( 'above', 'float' ) ) ) {
				$learnify_title = apply_filters( 'learnify_filter_sidebar_control_title', 'float' == $learnify_sidebar_position_ss ? esc_html__( 'Show Sidebar', 'learnify' ) : '' );
				$learnify_text  = apply_filters( 'learnify_filter_sidebar_control_text', 'above' == $learnify_sidebar_position_ss ? esc_html__( 'Show Sidebar', 'learnify' ) : '' );
				?>
				<a href="#" class="sidebar_control" title="<?php echo esc_attr( $learnify_title ); ?>"><?php echo esc_html( $learnify_text ); ?></a>
				<?php
			}
			?>
			<div class="sidebar_inner">
				<?php
				do_action( 'learnify_action_before_sidebar', 'sidebar' );
				learnify_show_layout( preg_replace( "/<\/aside>[\r\n\s]*<aside/", '</aside><aside', $learnify_out ) );
				do_action( 'learnify_action_after_sidebar', 'sidebar' );
				?>
			</div>
			<?php

			do_action( 'learnify_action_after_sidebar_wrap', 'sidebar' );

			?>
		</div>
		<div class="clearfix"></div>
		<?php
	}
}
