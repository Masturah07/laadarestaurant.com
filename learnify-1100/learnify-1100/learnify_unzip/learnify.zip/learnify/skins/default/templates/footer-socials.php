<?php
/**
 * The template to display the socials in the footer
 *
 * @package LEARNIFY
 * @since LEARNIFY 1.0.10
 */


// Socials
if ( learnify_is_on( learnify_get_theme_option( 'socials_in_footer' ) ) ) {
	$learnify_output = learnify_get_socials_links();
	if ( '' != $learnify_output ) {
		?>
		<div class="footer_socials_wrap socials_wrap">
			<div class="footer_socials_inner">
				<?php learnify_show_layout( $learnify_output ); ?>
			</div>
		</div>
		<?php
	}
}
