<?php
/**
 * The template to display the widgets area in the header
 *
 * @package LEARNIFY
 * @since LEARNIFY 1.0
 */

// Header sidebar
$learnify_header_name    = learnify_get_theme_option( 'header_widgets' );
$learnify_header_present = ! learnify_is_off( $learnify_header_name ) && is_active_sidebar( $learnify_header_name );
if ( $learnify_header_present ) {
	learnify_storage_set( 'current_sidebar', 'header' );
	$learnify_header_wide = learnify_get_theme_option( 'header_wide' );
	ob_start();
	if ( is_active_sidebar( $learnify_header_name ) ) {
		dynamic_sidebar( $learnify_header_name );
	}
	$learnify_widgets_output = ob_get_contents();
	ob_end_clean();
	if ( ! empty( $learnify_widgets_output ) ) {
		$learnify_widgets_output = preg_replace( "/<\/aside>[\r\n\s]*<aside/", '</aside><aside', $learnify_widgets_output );
		$learnify_need_columns   = strpos( $learnify_widgets_output, 'columns_wrap' ) === false;
		if ( $learnify_need_columns ) {
			$learnify_columns = max( 0, (int) learnify_get_theme_option( 'header_columns' ) );
			if ( 0 == $learnify_columns ) {
				$learnify_columns = min( 6, max( 1, learnify_tags_count( $learnify_widgets_output, 'aside' ) ) );
			}
			if ( $learnify_columns > 1 ) {
				$learnify_widgets_output = preg_replace( '/<aside([^>]*)class="widget/', '<aside$1class="column-1_' . esc_attr( $learnify_columns ) . ' widget', $learnify_widgets_output );
			} else {
				$learnify_need_columns = false;
			}
		}
		?>
		<div class="header_widgets_wrap widget_area<?php echo ! empty( $learnify_header_wide ) ? ' header_fullwidth' : ' header_boxed'; ?>">
			<?php do_action( 'learnify_action_before_sidebar_wrap', 'header' ); ?>
			<div class="header_widgets_inner widget_area_inner">
				<?php
				if ( ! $learnify_header_wide ) {
					?>
					<div class="content_wrap">
					<?php
				}
				if ( $learnify_need_columns ) {
					?>
					<div class="columns_wrap">
					<?php
				}
				do_action( 'learnify_action_before_sidebar', 'header' );
				learnify_show_layout( $learnify_widgets_output );
				do_action( 'learnify_action_after_sidebar', 'header' );
				if ( $learnify_need_columns ) {
					?>
					</div>	<!-- /.columns_wrap -->
					<?php
				}
				if ( ! $learnify_header_wide ) {
					?>
					</div>	<!-- /.content_wrap -->
					<?php
				}
				?>
			</div>	<!-- /.header_widgets_inner -->
			<?php do_action( 'learnify_action_after_sidebar_wrap', 'header' ); ?>
		</div>	<!-- /.header_widgets_wrap -->
		<?php
	}
}
