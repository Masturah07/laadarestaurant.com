<?php
/**
 * The template to display the background video in the header
 *
 * @package LEARNIFY
 * @since LEARNIFY 1.0.14
 */
$learnify_header_video = learnify_get_header_video();
$learnify_embed_video  = '';
if ( ! empty( $learnify_header_video ) && ! learnify_is_from_uploads( $learnify_header_video ) ) {
	if ( learnify_is_youtube_url( $learnify_header_video ) && preg_match( '/[=\/]([^=\/]*)$/', $learnify_header_video, $matches ) && ! empty( $matches[1] ) ) {
		?><div id="background_video" data-youtube-code="<?php echo esc_attr( $matches[1] ); ?>"></div>
		<?php
	} else {
		?>
		<div id="background_video"><?php learnify_show_layout( learnify_get_embed_video( $learnify_header_video ) ); ?></div>
		<?php
	}
}
