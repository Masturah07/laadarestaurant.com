<?php
/**
 * The template to display Admin notices
 *
 * @package LEARNIFY
 * @since LEARNIFY 1.0.1
 */

$learnify_theme_slug = get_option( 'template' );
$learnify_theme_obj  = wp_get_theme( $learnify_theme_slug );
?>
<div class="learnify_admin_notice learnify_welcome_notice notice notice-info is-dismissible" data-notice="admin">
	<?php
	// Theme image
	$learnify_theme_img = learnify_get_file_url( 'screenshot.jpg' );
	if ( '' != $learnify_theme_img ) {
		?>
		<div class="learnify_notice_image"><img src="<?php echo esc_url( $learnify_theme_img ); ?>" alt="<?php esc_attr_e( 'Theme screenshot', 'learnify' ); ?>"></div>
		<?php
	}

	// Title
	?>
	<h3 class="learnify_notice_title">
		<?php
		echo esc_html(
			sprintf(
				// Translators: Add theme name and version to the 'Welcome' message
				__( 'Welcome to %1$s v.%2$s', 'learnify' ),
				$learnify_theme_obj->get( 'Name' ) . ( LEARNIFY_THEME_FREE ? ' ' . __( 'Free', 'learnify' ) : '' ),
				$learnify_theme_obj->get( 'Version' )
			)
		);
		?>
	</h3>
	<?php

	// Description
	?>
	<div class="learnify_notice_text">
		<p class="learnify_notice_text_description">
			<?php
			echo str_replace( '. ', '.<br>', wp_kses_data( $learnify_theme_obj->description ) );
			?>
		</p>
		<p class="learnify_notice_text_info">
			<?php
			echo wp_kses_data( __( 'Attention! Plugin "ThemeREX Addons" is required! Please, install and activate it!', 'learnify' ) );
			?>
		</p>
	</div>
	<?php

	// Buttons
	?>
	<div class="learnify_notice_buttons">
		<?php
		// Link to the page 'About Theme'
		?>
		<a href="<?php echo esc_url( admin_url() . 'themes.php?page=learnify_about' ); ?>" class="button button-primary"><i class="dashicons dashicons-nametag"></i> 
			<?php
			echo esc_html__( 'Install plugin "ThemeREX Addons"', 'learnify' );
			?>
		</a>
	</div>
</div>
