<?php
/**
 * The template to display default site header
 *
 * @package LEARNIFY
 * @since LEARNIFY 1.0
 */

$learnify_header_css   = '';
$learnify_header_image = get_header_image();
$learnify_header_video = learnify_get_header_video();
if ( ! empty( $learnify_header_image ) && learnify_trx_addons_featured_image_override( is_singular() || learnify_storage_isset( 'blog_archive' ) || is_category() ) ) {
	$learnify_header_image = learnify_get_current_mode_image( $learnify_header_image );
}

?><header class="top_panel top_panel_default
	<?php
	echo ! empty( $learnify_header_image ) || ! empty( $learnify_header_video ) ? ' with_bg_image' : ' without_bg_image';
	if ( '' != $learnify_header_video ) {
		echo ' with_bg_video';
	}
	if ( '' != $learnify_header_image ) {
		echo ' ' . esc_attr( learnify_add_inline_css_class( 'background-image: url(' . esc_url( $learnify_header_image ) . ');' ) );
	}
	if ( is_single() && has_post_thumbnail() ) {
		echo ' with_featured_image';
	}
	if ( learnify_is_on( learnify_get_theme_option( 'header_fullheight' ) ) ) {
		echo ' header_fullheight learnify-full-height';
	}
	$learnify_header_scheme = learnify_get_theme_option( 'header_scheme' );
	if ( ! empty( $learnify_header_scheme ) && ! learnify_is_inherit( $learnify_header_scheme  ) ) {
		echo ' scheme_' . esc_attr( $learnify_header_scheme );
	}
	?>
">
	<?php

	// Background video
	if ( ! empty( $learnify_header_video ) ) {
		get_template_part( apply_filters( 'learnify_filter_get_template_part', 'templates/header-video' ) );
	}

	// Main menu
	get_template_part( apply_filters( 'learnify_filter_get_template_part', 'templates/header-navi' ) );

	// Mobile header
	if ( learnify_is_on( learnify_get_theme_option( 'header_mobile_enabled' ) ) ) {
		get_template_part( apply_filters( 'learnify_filter_get_template_part', 'templates/header-mobile' ) );
	}

	// Page title and breadcrumbs area
	if ( ! is_single() ) {
		get_template_part( apply_filters( 'learnify_filter_get_template_part', 'templates/header-title' ) );
	}

	// Header widgets area
	get_template_part( apply_filters( 'learnify_filter_get_template_part', 'templates/header-widgets' ) );
	?>
</header>
