<?php
/**
 * The Classic template to display the content
 *
 * Used for index/archive/search.
 *
 * @package LEARNIFY
 * @since LEARNIFY 1.0
 */

$learnify_template_args = get_query_var( 'learnify_template_args' );

if ( is_array( $learnify_template_args ) ) {
	$learnify_columns    = empty( $learnify_template_args['columns'] ) ? 2 : max( 1, $learnify_template_args['columns'] );
	$learnify_blog_style = array( $learnify_template_args['type'], $learnify_columns );
    $learnify_columns_class = learnify_get_column_class( 1, $learnify_columns, ! empty( $learnify_template_args['columns_tablet']) ? $learnify_template_args['columns_tablet'] : '', ! empty($learnify_template_args['columns_mobile']) ? $learnify_template_args['columns_mobile'] : '' );
} else {
	$learnify_blog_style = explode( '_', learnify_get_theme_option( 'blog_style' ) );
	$learnify_columns    = empty( $learnify_blog_style[1] ) ? 2 : max( 1, $learnify_blog_style[1] );
    $learnify_columns_class = learnify_get_column_class( 1, $learnify_columns );
}
$learnify_expanded   = ! learnify_sidebar_present() && learnify_get_theme_option( 'expand_content' ) == 'expand';

$learnify_post_format = get_post_format();
$learnify_post_format = empty( $learnify_post_format ) ? 'standard' : str_replace( 'post-format-', '', $learnify_post_format );

?><div class="<?php
	if ( ! empty( $learnify_template_args['slider'] ) ) {
		echo ' slider-slide swiper-slide';
	} else {
		echo ( learnify_is_blog_style_use_masonry( $learnify_blog_style[0] ) ? 'masonry_item masonry_item-1_' . esc_attr( $learnify_columns ) : esc_attr( $learnify_columns_class ) );
	}
?>"><article id="post-<?php the_ID(); ?>" data-post-id="<?php the_ID(); ?>"
	<?php
	post_class(
		'post_item post_item_container post_format_' . esc_attr( $learnify_post_format )
				. ' post_layout_classic post_layout_classic_' . esc_attr( $learnify_columns )
				. ' post_layout_' . esc_attr( $learnify_blog_style[0] )
				. ' post_layout_' . esc_attr( $learnify_blog_style[0] ) . '_' . esc_attr( $learnify_columns )
	);
	learnify_add_blog_animation( $learnify_template_args );
	?>
>
	<?php

	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?>
		<span class="post_label label_sticky"></span>
		<?php
	}

	// Featured image
	$learnify_hover      = ! empty( $learnify_template_args['hover'] ) && ! learnify_is_inherit( $learnify_template_args['hover'] )
							? $learnify_template_args['hover']
							: learnify_get_theme_option( 'image_hover' );

	$learnify_components = ! empty( $learnify_template_args['meta_parts'] )
							? ( is_array( $learnify_template_args['meta_parts'] )
								? $learnify_template_args['meta_parts']
								: explode( ',', $learnify_template_args['meta_parts'] )
								)
							: learnify_array_get_keys_by_value( learnify_get_theme_option( 'meta_parts' ) );

	learnify_show_post_featured( apply_filters( 'learnify_filter_args_featured',
		array(
			'thumb_size' => learnify_get_thumb_size(
				'classic' == $learnify_blog_style[0]
						? ( strpos( learnify_get_theme_option( 'body_style' ), 'full' ) !== false
								? ( $learnify_columns > 2 ? 'big' : 'huge' )
								: ( $learnify_columns > 2
									? ( $learnify_expanded ? 'square' : 'square' )
									: ($learnify_columns > 1 ? 'square' : ( $learnify_expanded ? 'huge' : 'big' ))
									)
							)
						: ( strpos( learnify_get_theme_option( 'body_style' ), 'full' ) !== false
								? ( $learnify_columns > 2 ? 'masonry-big' : 'full' )
								: ($learnify_columns === 1 ? ( $learnify_expanded ? 'huge' : 'big' ) : ( $learnify_columns <= 2 && $learnify_expanded ? 'masonry-big' : 'masonry' ))
							)
			),
			'hover'      => $learnify_hover,
			'meta_parts' => $learnify_components,
			'no_links'   => ! empty( $learnify_template_args['no_links'] ),
        ),
        'content-classic',
        $learnify_template_args
    ) );

	// Title and post meta
	$learnify_show_title = get_the_title() != '';
	$learnify_show_meta  = count( $learnify_components ) > 0 && ! in_array( $learnify_hover, array( 'border', 'pull', 'slide', 'fade', 'info' ) );

	if ( $learnify_show_title ) {
		?>
		<div class="post_header entry-header">
			<?php

			// Post meta
			if ( apply_filters( 'learnify_filter_show_blog_meta', $learnify_show_meta, $learnify_components, 'classic' ) ) {
				if ( count( $learnify_components ) > 0 ) {
					do_action( 'learnify_action_before_post_meta' );
					learnify_show_post_meta(
						apply_filters(
							'learnify_filter_post_meta_args', array(
							'components' => join( ',', $learnify_components ),
							'seo'        => false,
							'echo'       => true,
						), $learnify_blog_style[0], $learnify_columns
						)
					);
					do_action( 'learnify_action_after_post_meta' );
				}
			}

			// Post title
			if ( apply_filters( 'learnify_filter_show_blog_title', true, 'classic' ) ) {
				do_action( 'learnify_action_before_post_title' );
				if ( empty( $learnify_template_args['no_links'] ) ) {
					the_title( sprintf( '<h4 class="post_title entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' );
				} else {
					the_title( '<h4 class="post_title entry-title">', '</h4>' );
				}
				do_action( 'learnify_action_after_post_title' );
			}

			if( !in_array( $learnify_post_format, array( 'quote', 'aside', 'link', 'status' ) ) ) {
				// More button
				if ( apply_filters( 'learnify_filter_show_blog_readmore', ! $learnify_show_title || ! empty( $learnify_template_args['more_button'] ), 'classic' ) ) {
					if ( empty( $learnify_template_args['no_links'] ) ) {
						do_action( 'learnify_action_before_post_readmore' );
						learnify_show_post_more_link( $learnify_template_args, '<div class="more-wrap">', '</div>' );
						do_action( 'learnify_action_after_post_readmore' );
					}
				}
			}
			?>
		</div><!-- .entry-header -->
		<?php
	}

	// Post content
	if( in_array( $learnify_post_format, array( 'quote', 'aside', 'link', 'status' ) ) ) {
		ob_start();
		if (apply_filters('learnify_filter_show_blog_excerpt', empty($learnify_template_args['hide_excerpt']) && learnify_get_theme_option('excerpt_length') > 0, 'classic')) {
			learnify_show_post_content($learnify_template_args, '<div class="post_content_inner">', '</div>');
		}
		// More button
		if(! empty( $learnify_template_args['more_button'] )) {
			if ( empty( $learnify_template_args['no_links'] ) ) {
				do_action( 'learnify_action_before_post_readmore' );
				learnify_show_post_more_link( $learnify_template_args, '<div class="more-wrap">', '</div>' );
				do_action( 'learnify_action_after_post_readmore' );
			}
		}
		$learnify_content = ob_get_contents();
		ob_end_clean();
		learnify_show_layout($learnify_content, '<div class="post_content entry-content">', '</div><!-- .entry-content -->');
	}
	?>

</article></div><?php
// Need opening PHP-tag above, because <div> is a inline-block element (used as column)!
