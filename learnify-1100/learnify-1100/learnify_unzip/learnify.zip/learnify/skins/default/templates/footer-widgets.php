<?php
/**
 * The template to display the widgets area in the footer
 *
 * @package LEARNIFY
 * @since LEARNIFY 1.0.10
 */

// Footer sidebar
$learnify_footer_name    = learnify_get_theme_option( 'footer_widgets' );
$learnify_footer_present = ! learnify_is_off( $learnify_footer_name ) && is_active_sidebar( $learnify_footer_name );
if ( $learnify_footer_present ) {
	learnify_storage_set( 'current_sidebar', 'footer' );
	$learnify_footer_wide = learnify_get_theme_option( 'footer_wide' );
	ob_start();
	if ( is_active_sidebar( $learnify_footer_name ) ) {
		dynamic_sidebar( $learnify_footer_name );
	}
	$learnify_out = trim( ob_get_contents() );
	ob_end_clean();
	if ( ! empty( $learnify_out ) ) {
		$learnify_out          = preg_replace( "/<\\/aside>[\r\n\s]*<aside/", '</aside><aside', $learnify_out );
		$learnify_need_columns = true;   //or check: strpos($learnify_out, 'columns_wrap')===false;
		if ( $learnify_need_columns ) {
			$learnify_columns = max( 0, (int) learnify_get_theme_option( 'footer_columns' ) );			
			if ( 0 == $learnify_columns ) {
				$learnify_columns = min( 4, max( 1, learnify_tags_count( $learnify_out, 'aside' ) ) );
			}
			if ( $learnify_columns > 1 ) {
				$learnify_out = preg_replace( '/<aside([^>]*)class="widget/', '<aside$1class="column-1_' . esc_attr( $learnify_columns ) . ' widget', $learnify_out );
			} else {
				$learnify_need_columns = false;
			}
		}
		?>
		<div class="footer_widgets_wrap widget_area<?php echo ! empty( $learnify_footer_wide ) ? ' footer_fullwidth' : ''; ?> sc_layouts_row sc_layouts_row_type_normal">
			<?php do_action( 'learnify_action_before_sidebar_wrap', 'footer' ); ?>
			<div class="footer_widgets_inner widget_area_inner">
				<?php
				if ( ! $learnify_footer_wide ) {
					?>
					<div class="content_wrap">
					<?php
				}
				if ( $learnify_need_columns ) {
					?>
					<div class="columns_wrap">
					<?php
				}
				do_action( 'learnify_action_before_sidebar', 'footer' );
				learnify_show_layout( $learnify_out );
				do_action( 'learnify_action_after_sidebar', 'footer' );
				if ( $learnify_need_columns ) {
					?>
					</div><!-- /.columns_wrap -->
					<?php
				}
				if ( ! $learnify_footer_wide ) {
					?>
					</div><!-- /.content_wrap -->
					<?php
				}
				?>
			</div><!-- /.footer_widgets_inner -->
			<?php do_action( 'learnify_action_after_sidebar_wrap', 'footer' ); ?>
		</div><!-- /.footer_widgets_wrap -->
		<?php
	}
}
