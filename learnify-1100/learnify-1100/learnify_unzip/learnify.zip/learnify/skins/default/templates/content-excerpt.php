<?php
/**
 * The default template to display the content
 *
 * Used for index/archive/search.
 *
 * @package LEARNIFY
 * @since LEARNIFY 1.0
 */

$learnify_template_args = get_query_var( 'learnify_template_args' );
$learnify_columns = 1;
if ( is_array( $learnify_template_args ) ) {
	$learnify_columns    = empty( $learnify_template_args['columns'] ) ? 1 : max( 1, $learnify_template_args['columns'] );
	$learnify_blog_style = array( $learnify_template_args['type'], $learnify_columns );
	if ( ! empty( $learnify_template_args['slider'] ) ) {
		?><div class="slider-slide swiper-slide">
		<?php
	} elseif ( $learnify_columns > 1 ) {
	    $learnify_columns_class = learnify_get_column_class( 1, $learnify_columns, ! empty( $learnify_template_args['columns_tablet']) ? $learnify_template_args['columns_tablet'] : '', ! empty($learnify_template_args['columns_mobile']) ? $learnify_template_args['columns_mobile'] : '' );
		?>
		<div class="<?php echo esc_attr( $learnify_columns_class ); ?>">
		<?php
	}
}
$learnify_expanded    = ! learnify_sidebar_present() && learnify_get_theme_option( 'expand_content' ) == 'expand';
$learnify_post_format = get_post_format();
$learnify_post_format = empty( $learnify_post_format ) ? 'standard' : str_replace( 'post-format-', '', $learnify_post_format );
?>
<article id="post-<?php the_ID(); ?>" data-post-id="<?php the_ID(); ?>"
	<?php
	post_class( 'post_item post_item_container post_layout_excerpt post_format_' . esc_attr( $learnify_post_format ) );
	learnify_add_blog_animation( $learnify_template_args );
	?>
>
	<?php

	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?>
		<span class="post_label label_sticky"></span>
		<?php
	}

	// Featured image
	$learnify_hover      = ! empty( $learnify_template_args['hover'] ) && ! learnify_is_inherit( $learnify_template_args['hover'] )
							? $learnify_template_args['hover']
							: learnify_get_theme_option( 'image_hover' );
	$learnify_components = ! empty( $learnify_template_args['meta_parts'] )
							? ( is_array( $learnify_template_args['meta_parts'] )
								? $learnify_template_args['meta_parts']
								: array_map( 'trim', explode( ',', $learnify_template_args['meta_parts'] ) )
								)
							: learnify_array_get_keys_by_value( learnify_get_theme_option( 'meta_parts' ) );



	// Title and post meta
	$learnify_show_title = get_the_title() != '';
	$learnify_show_meta  = count( $learnify_components ) > 0 && ! in_array( $learnify_hover, array( 'border', 'pull', 'slide', 'fade', 'info' ) );

    // Categories
	$learnify_meta_cat = '';
	$learnify_show_meta_cat_in_img = true;
	if ($learnify_show_meta && in_array( 'categories', $learnify_components )	) {
		$learnify_meta_cat = learnify_show_post_meta( apply_filters(
											'learnify_filter_post_meta_args',
											array(
												'components' => 'categories',
												'seo'        => false,
												'echo'       => false,
												'cat_sep'    => ', ',
												'class'		 => 'categories-extra-wrap'
												),
											'hover_' . $learnify_hover, 1
											)
							);
		if(in_array( $learnify_post_format, array( 'audio' ) )
		|| !has_post_thumbnail()
		) {
			$learnify_show_meta_cat_in_img = false;
		}
		$learnify_components = learnify_array_delete_by_value( $learnify_components, 'categories' );
	}


	// Date
	$learnify_meta_date = '';

	if (in_array( 'date', $learnify_components )) {
		$learnify_meta_date = learnify_show_post_meta( apply_filters(
											'learnify_filter_post_meta_args',
											array(
												'components' => 'date',
												'seo'        => false,
												'echo'       => false,
												'date_format'  => '<b>j</b> M',
												'class'		 => 'date-extra-wrap'
												),
											'hover_' . $learnify_hover, 1
											)
							);
		$learnify_components = learnify_array_delete_by_value( $learnify_components, 'date' );
	}




	learnify_show_post_featured( apply_filters( 'learnify_filter_args_featured',
		array(
			'no_links'   => ! empty( $learnify_template_args['no_links'] ),
			'hover'      => $learnify_hover,
			'meta_parts' => $learnify_components,
			'thumb_size' => learnify_get_thumb_size( strpos( learnify_get_theme_option( 'body_style' ), 'full' ) !== false
								? 'full'
								: ( $learnify_expanded 
									? 'huge' 
									: 'big' 
									)
								),
            'post_info' => ($learnify_show_meta_cat_in_img ? $learnify_meta_cat : '')
		),
		'content-excerpt',
		$learnify_template_args
	) );




?>
    <div class="post_inner_wrap_excerpt <?php echo esc_attr($learnify_meta_date ? 'with_date' : 'without_date'); ?>">
        <?php



    if($learnify_meta_date) {
        learnify_show_layout($learnify_meta_date);
    }

?>
<div class="post_inner_excerpt_content">

<?php

    if(!$learnify_show_meta_cat_in_img) {
        learnify_show_layout($learnify_meta_cat);
    }


	if ( $learnify_show_title ) {
		?>
		<div class="post_header entry-header">
			<?php

			// Post title
			if ( apply_filters( 'learnify_filter_show_blog_title', true, 'excerpt' ) ) {
				do_action( 'learnify_action_before_post_title' );
				if ( empty( $learnify_template_args['no_links'] ) ) {
					the_title( sprintf( '<h3 class="post_title entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h3>' );
				} else {
					the_title( '<h3 class="post_title entry-title">', '</h3>' );
				}
				do_action( 'learnify_action_after_post_title' );
			}
			?>
		</div><!-- .post_header -->
		<?php
	}

	// Post content
	if ( apply_filters( 'learnify_filter_show_blog_excerpt', empty( $learnify_template_args['hide_excerpt'] ) && learnify_get_theme_option( 'excerpt_length' ) > 0, 'excerpt' ) ) {
		?>
		<div class="post_content entry-content">
			<?php

            // Post meta
            if ( apply_filters( 'learnify_filter_show_blog_meta', $learnify_show_meta, $learnify_components, 'excerpt' ) ) {
                if ( count( $learnify_components ) > 0 ) {
                    do_action( 'learnify_action_before_post_meta' );
                    learnify_show_post_meta(
                        apply_filters(
                            'learnify_filter_post_meta_args', array(
                                'components' => join( ',', $learnify_components ),
                                'seo'        => false,
                                'echo'       => true,
                            ), 'excerpt', 1
                        )
                    );
                    do_action( 'learnify_action_after_post_meta' );
                }
            }

			if ( learnify_get_theme_option( 'blog_content' ) == 'fullpost' ) {
				// Post content area
				?>
				<div class="post_content_inner">
					<?php
					do_action( 'learnify_action_before_full_post_content' );
					the_content( '' );
					do_action( 'learnify_action_after_full_post_content' );
					?>
				</div>
				<?php
				// Inner pages
				wp_link_pages(
					array(
						'before'      => '<div class="page_links"><span class="page_links_title">' . esc_html__( 'Pages:', 'learnify' ) . '</span>',
						'after'       => '</div>',
						'link_before' => '<span>',
						'link_after'  => '</span>',
						'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'learnify' ) . ' </span>%',
						'separator'   => '<span class="screen-reader-text">, </span>',
					)
				);
			} else {
				// Post content area
				learnify_show_post_content( $learnify_template_args, '<div class="post_content_inner">', '</div>' );
			}

			// More button
			if ( apply_filters( 'learnify_filter_show_blog_readmore',  ! isset( $learnify_template_args['more_button'] ) || ! empty( $learnify_template_args['more_button'] ), 'excerpt' ) ) {
				if ( empty( $learnify_template_args['no_links'] ) ) {
					do_action( 'learnify_action_before_post_readmore' );
					if ( learnify_get_theme_option( 'blog_content' ) != 'fullpost' ) {
						learnify_show_post_more_link( $learnify_template_args, '<p>', '</p>' );
					} else {
						learnify_show_post_comments_link( $learnify_template_args, '<p>', '</p>' );
					}
					do_action( 'learnify_action_after_post_readmore' );
				}
			}

			?>
		</div><!-- .entry-content -->
		<?php
	}
	?>
	</div>
	</div>
</article>
<?php

if ( is_array( $learnify_template_args ) ) {
	if ( ! empty( $learnify_template_args['slider'] ) || $learnify_columns > 1 ) {
		?>
		</div>
		<?php
	}
}
