<?php
/**
 * The Portfolio template to display the content
 *
 * Used for index/archive/search.
 *
 * @package LEARNIFY
 * @since LEARNIFY 1.0
 */

$learnify_template_args = get_query_var( 'learnify_template_args' );
if ( is_array( $learnify_template_args ) ) {
	$learnify_columns    = empty( $learnify_template_args['columns'] ) ? 2 : max( 1, $learnify_template_args['columns'] );
	$learnify_blog_style = array( $learnify_template_args['type'], $learnify_columns );
    $learnify_columns_class = learnify_get_column_class( 1, $learnify_columns, ! empty( $learnify_template_args['columns_tablet']) ? $learnify_template_args['columns_tablet'] : '', ! empty($learnify_template_args['columns_mobile']) ? $learnify_template_args['columns_mobile'] : '' );
} else {
	$learnify_blog_style = explode( '_', learnify_get_theme_option( 'blog_style' ) );
	$learnify_columns    = empty( $learnify_blog_style[1] ) ? 2 : max( 1, $learnify_blog_style[1] );
    $learnify_columns_class = learnify_get_column_class( 1, $learnify_columns );
}

$learnify_post_format = get_post_format();
$learnify_post_format = empty( $learnify_post_format ) ? 'standard' : str_replace( 'post-format-', '', $learnify_post_format );

?><div class="
<?php
if ( ! empty( $learnify_template_args['slider'] ) ) {
	echo ' slider-slide swiper-slide';
} else {
	echo ( learnify_is_blog_style_use_masonry( $learnify_blog_style[0] ) ? 'masonry_item masonry_item-1_' . esc_attr( $learnify_columns ) : esc_attr( $learnify_columns_class ));
}
?>
"><article id="post-<?php the_ID(); ?>" 
	<?php
	post_class(
		'post_item post_item_container post_format_' . esc_attr( $learnify_post_format )
		. ' post_layout_portfolio'
		. ' post_layout_portfolio_' . esc_attr( $learnify_columns )
		. ( 'portfolio' != $learnify_blog_style[0] ? ' ' . esc_attr( $learnify_blog_style[0] )  . '_' . esc_attr( $learnify_columns ) : '' )
	);
	learnify_add_blog_animation( $learnify_template_args );
	?>
>
<?php

	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?>
		<span class="post_label label_sticky"></span>
		<?php
	}

	$learnify_hover   = ! empty( $learnify_template_args['hover'] ) && ! learnify_is_inherit( $learnify_template_args['hover'] )
								? $learnify_template_args['hover']
								: learnify_get_theme_option( 'image_hover' );

	if ( 'dots' == $learnify_hover ) {
		$learnify_post_link = empty( $learnify_template_args['no_links'] )
								? ( ! empty( $learnify_template_args['link'] )
									? $learnify_template_args['link']
									: get_permalink()
									)
								: '';
		$learnify_target    = ! empty( $learnify_post_link ) && false === strpos( $learnify_post_link, home_url() )
								? ' target="_blank" rel="nofollow"'
								: '';
	}
	
	// Meta parts
	$learnify_components = ! empty( $learnify_template_args['meta_parts'] )
							? ( is_array( $learnify_template_args['meta_parts'] )
								? $learnify_template_args['meta_parts']
								: explode( ',', $learnify_template_args['meta_parts'] )
								)
							: learnify_array_get_keys_by_value( learnify_get_theme_option( 'meta_parts' ) );

	// Featured image
	learnify_show_post_featured( apply_filters( 'learnify_filter_args_featured',
        array(
			'hover'         => $learnify_hover,
			'no_links'      => ! empty( $learnify_template_args['no_links'] ),
			'thumb_size'    => learnify_get_thumb_size(
									learnify_is_blog_style_use_masonry( $learnify_blog_style[0] )
										? (	strpos( learnify_get_theme_option( 'body_style' ), 'full' ) !== false || $learnify_columns < 3
											? 'masonry-big'
											: 'masonry'
											)
										: (	strpos( learnify_get_theme_option( 'body_style' ), 'full' ) !== false || $learnify_columns < 3
											? 'square'
											: 'square'
											)
								),
			'thumb_bg' => learnify_is_blog_style_use_masonry( $learnify_blog_style[0] ) ? false : true,
			'show_no_image' => true,
			'meta_parts'    => $learnify_components,
			'class'         => 'dots' == $learnify_hover ? 'hover_with_info' : '',
			'post_info'     => 'dots' == $learnify_hover
										? '<div class="post_info"><h5 class="post_title">'
											. ( ! empty( $learnify_post_link )
												? '<a href="' . esc_url( $learnify_post_link ) . '"' . ( ! empty( $target ) ? $target : '' ) . '>'
												: ''
												)
												. esc_html( get_the_title() ) 
											. ( ! empty( $learnify_post_link )
												? '</a>'
												: ''
												)
											. '</h5></div>'
										: '',
            'thumb_ratio'   => 'info' == $learnify_hover ?  '100:102' : '',
        ),
        'content-portfolio',
        $learnify_template_args
    ) );
	?>
</article></div><?php
// Need opening PHP-tag above, because <article> is a inline-block element (used as column)!