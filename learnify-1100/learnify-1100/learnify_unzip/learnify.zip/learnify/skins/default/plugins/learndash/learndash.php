<?php
/* Tribe Events Calendar support functions
------------------------------------------------------------------------------- */

// Theme init priorities:
// 1 - register filters, that add/remove lists items for the Theme Options
if ( ! function_exists( 'learnify_sfwd_lms_theme_setup1' ) ) {
	add_action( 'after_setup_theme', 'learnify_sfwd_lms_theme_setup1', 1 );
	function learnify_sfwd_lms_theme_setup1() {
		add_filter( 'learnify_filter_list_sidebars', 'learnify_sfwd_lms_list_sidebars' );
	}
}

// Theme init priorities:
// 3 - add/remove Theme Options elements
if ( ! function_exists( 'learnify_sfwd_lms_theme_setup3' ) ) {
	add_action( 'after_setup_theme', 'learnify_sfwd_lms_theme_setup3', 3 );
	function learnify_sfwd_lms_theme_setup3() {
		if ( learnify_exists_sfwd_lms() ) {
			// Section 'Tribe Events'
			learnify_storage_merge_array(
				'options', '', array_merge(
					array(
						'learndash' => array(
							'title' => esc_html__( 'LearnDash', 'learnify' ),
							'desc'  => wp_kses_data( __( 'Select parameters to display the learndash pages', 'learnify' ) ),
							'icon'  => 'icon-events',
							'type'  => 'section',
						),
					),
					learnify_options_get_list_cpt_options( 'learndash', esc_html__( 'LearnDash', 'learnify' ) )
				)
			);
		}
	}
}

// Theme init priorities:
// 9 - register other filters (for installer, etc.)
if ( ! function_exists( 'learnify_sfwd_lms_theme_setup9' ) ) {
	add_action( 'after_setup_theme', 'learnify_sfwd_lms_theme_setup9', 9 );
	function learnify_sfwd_lms_theme_setup9() {
		if ( learnify_exists_sfwd_lms() ) {
            add_action( 'wp_enqueue_scripts', 'learnify_sfwd_lms_frontend_scripts', 1100 );
            add_action( 'wp_enqueue_scripts', 'learnify_sfwd_lms_responsive_styles', 2000 );
            add_filter( 'learnify_filter_merge_styles', 'learnify_sfwd_lms_merge_styles' );
            add_filter( 'learnify_filter_merge_styles_responsive', 'learnify_sfwd_lms_merge_styles_responsive' );
			add_filter( 'learnify_filter_detect_blog_mode', 'learnify_sfwd_lms_detect_blog_mode' );
		}
		if ( is_admin() ) {
			add_filter( 'learnify_filter_tgmpa_required_plugins', 'learnify_sfwd_lms_tgmpa_required_plugins' );
		}

	}
}

// Filter to add in the required plugins list
if ( ! function_exists( 'learnify_sfwd_lms_tgmpa_required_plugins' ) ) {
	//Handler of the add_filter('learnify_filter_tgmpa_required_plugins',	'learnify_sfwd_lms_tgmpa_required_plugins');
	function learnify_sfwd_lms_tgmpa_required_plugins( $list = array() ) {
		if ( learnify_storage_isset( 'required_plugins', 'learndash' ) && learnify_storage_get_array( 'required_plugins', 'learndash', 'install' ) !== false ) {
			$list[] = array(
				'name'     => learnify_storage_get_array( 'required_plugins', 'learndash', 'title' ),
				'slug'     => 'learndash',
				'required' => false,
			);
		}
		return $list;
	}
}



// Check if Tribe Events is installed and activated
if ( ! function_exists( 'learnify_exists_sfwd_lms' ) ) {
	function learnify_exists_sfwd_lms() {
		return class_exists( 'LearnDash_Addon_Updater' );
	}
}

// Return true, if current page is any sfwd_lms page
if ( ! function_exists( 'learnify_is_sfwd_lms_page' ) ) {
	function learnify_is_sfwd_lms_page() {
		$rez = false;
		if ( learnify_exists_sfwd_lms() ) {
		    if ( ! is_search() ) {
				$rez =     get_post_type() == 'sfwd-courses'
						|| get_post_type() =='sfwd-lessons'
						|| get_post_type() =='sfwd-quiz';
			}
		}
		return $rez;
	}
}


// Detect current blog mode
if ( ! function_exists( 'learnify_sfwd_lms_detect_blog_mode' ) ) {
	//Handler of the add_filter( 'learnify_filter_detect_blog_mode', 'learnify_sfwd_lms_detect_blog_mode' );
	function learnify_sfwd_lms_detect_blog_mode( $mode = '' ) {
		if ( learnify_is_sfwd_lms_page() ) {
			$mode = 'learndash';
		}
		return $mode;
	}
}



// Add Tribe Events specific items into lists
//------------------------------------------------------------------------

// Add sidebar
if ( ! function_exists( 'learnify_sfwd_lms_list_sidebars' ) ) {
	//Handler of the add_filter( 'learnify_filter_list_sidebars', 'learnify_sfwd_lms_list_sidebars' );
	function learnify_sfwd_lms_list_sidebars( $list = array() ) {
		$list['sfwd_lms_widgets'] = array(
			'name'        => esc_html__( 'LearnDash sidebar', 'learnify' ),
			'description' => esc_html__( 'Widgets to be shown on the LearnDash pages', 'learnify' ),
		);
		return $list;
	}
}

// Add plugin-specific colors and fonts to the custom CSS
if ( learnify_exists_sfwd_lms() ) {
    require_once learnify_get_file_dir( 'plugins/learndash/learndash.php' );
}
// Merge custom styles
if ( ! function_exists( 'learnify_sfwd_lms_merge_styles' ) ) {
    //Handler of the add_filter('learnify_filter_merge_styles', 'learnify_sfwd_lms_merge_styles');
    function learnify_sfwd_lms_merge_styles( $list ) {
        $list[] = 'plugins/learndash/learndash.css';
        return $list;
    }
}

// Merge responsive styles
if ( ! function_exists( 'learnify_sfwd_lms_merge_styles_responsive' ) ) {
    //Handler of the add_filter('learnify_filter_merge_styles_responsive', 'learnify_sfwd_lms_merge_styles_responsive');
    function learnify_sfwd_lms_merge_styles_responsive( $list ) {
        $list[] = 'plugins/learndash/learndash-responsive.css';
        return $list;
    }
}
// Enqueue responsive styles for frontend
if ( ! function_exists( 'learnify_sfwd_lms_responsive_styles' ) ) {
    //Handler of the add_action( 'wp_enqueue_scripts', 'learnify_sfwd_lms_responsive_styles', 2000 );
    function learnify_sfwd_lms_responsive_styles() {
        if ( learnify_is_on( learnify_get_theme_option( 'debug_mode' ) ) ) {
            $learnify_url = learnify_get_file_url( 'plugins/learndash/learndash-responsive.css' );
            if ( '' != $learnify_url ) {
                wp_enqueue_style( 'learnify-learndash-responsive', $learnify_url, array(), null );
            }
        }
    }
}
// Enqueue styles for frontend
if ( ! function_exists( 'learnify_sfwd_lms_frontend_scripts' ) ) {
    //Handler of the add_action( 'wp_enqueue_scripts', 'learnify_sfwd_lms_frontend_scripts', 1100 );
    function learnify_sfwd_lms_frontend_scripts() {
        if ( learnify_is_on( learnify_get_theme_option( 'debug_mode' ) ) ) {
            $learnify_url = learnify_get_file_url( 'plugins/learndash/learndash.css' );
            if ( '' != $learnify_url ) {
                wp_enqueue_style( 'learnify-learndash', $learnify_url, array(), null );
            }
        }
    }
}
